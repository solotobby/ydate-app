export type Color = string | CanvasGradient | CanvasPattern;
